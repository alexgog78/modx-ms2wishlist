<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Wishlist.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Wishlist
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Wishlist
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'miniShop2' => '>=2.4.0',
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '747479dccda7e7c5058be4f65076a83f',
      'native_key' => 'ms2wishlist',
      'filename' => 'modNamespace/aaf0cb883e1c9b40bb80e85fc963de1e.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '633347c7841c2d023505e3f6a63ebd8b',
      'native_key' => '633347c7841c2d023505e3f6a63ebd8b',
      'filename' => 'xPDOFileVehicle/630ad048afc19a505f4984804e3c0380.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e279f98af4ce3dbc1718ee16ebbd7d4c',
      'native_key' => 'e279f98af4ce3dbc1718ee16ebbd7d4c',
      'filename' => 'xPDOFileVehicle/90dadc15806e67d8946504236db6b52c.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79d216a01750142c8dd246f491e651a6',
      'native_key' => 'ms2wishlist_check_context',
      'filename' => 'modSystemSetting/a55b8658104cd47e690c314c1c6948e5.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd135780e85e4df189057320c6c9149ad',
      'native_key' => 'ms2wishlist_frontend_css',
      'filename' => 'modSystemSetting/58138b0c107c970e35c7de16f23b1aea.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8db29a9ee618b298b2b912dadbdda52a',
      'native_key' => 'ms2wishlist_frontend_js',
      'filename' => 'modSystemSetting/4904f6914ead00a14bf75808a7a1f5e5.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'f2669e6ead52e64a888cb530eb79607a',
      'native_key' => 0,
      'filename' => 'modChunk/38783c69359034f8a5aa52622bb32a42.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '9d8fa46a19f30312264ec7c5857adc76',
      'native_key' => 0,
      'filename' => 'modChunk/cf9c88ed679a5dbd0fbfa790729d60ef.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'f1ffb52b0276bd0e85f9d7d577290322',
      'native_key' => 0,
      'filename' => 'modChunk/8bcb4e8b8a7cd2524453dc08c3068910.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'd53647962d36ab33c95b0fa81068de9b',
      'native_key' => 0,
      'filename' => 'modChunk/8c81d896790b566043788a8dbae35018.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'dc82d5ae202a3f4b1722d802368718f1',
      'native_key' => 0,
      'filename' => 'modSnippet/3723147e0ef964701a364e4d1474656a.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '3bbaed50e7dba8bd9315828baa956b49',
      'native_key' => 0,
      'filename' => 'modSnippet/c7e473c3c84ce2b1aad927ef3802619a.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '08aa27743e90c97b54a55001e20459a3',
      'native_key' => 0,
      'filename' => 'modSnippet/9f397993f790fc215a75845806d9d90f.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '6b0eb64f25d34672167ccfdf94a66425',
      'native_key' => 0,
      'filename' => 'modPlugin/96d76f27ffd928e7d95e0aa126581a22.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '15b1e974b7addd0575c3bae72c49eb1c',
      'native_key' => 1,
      'filename' => 'modCategory/af09becab515a7987c1b4f6f244ece2f.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'e8e421605d3ad5bd306144c4cc302e9c',
      'native_key' => 'e8e421605d3ad5bd306144c4cc302e9c',
      'filename' => 'xPDOScriptVehicle/2138814056ce4ae9e0d35b98832656ba.vehicle',
      'namespace' => 'ms2wishlist',
    ),
  ),
);