<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Wishlist.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Wishlist
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Wishlist
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'miniShop2' => '>=2.4.0',
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b8d74c9eb4cdb40027ee660a7a10e04f',
      'native_key' => 'ms2wishlist',
      'filename' => 'modNamespace/47c821c4c785fab9786a507fd880e188.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'bc1cad4db8ad911e1314d44687499e62',
      'native_key' => 'bc1cad4db8ad911e1314d44687499e62',
      'filename' => 'xPDOFileVehicle/a1c9a0d30c7b48c33959c157e8fb8476.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4f694402cefb45007a2f014209e863da',
      'native_key' => '4f694402cefb45007a2f014209e863da',
      'filename' => 'xPDOFileVehicle/00c1291304259ba2bf008b2ccd92d388.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9433df01c642b50f06617602a36769ac',
      'native_key' => 'ms2wishlist_check_context',
      'filename' => 'modSystemSetting/924ed693b9f1f5d5a411d5907d1af51f.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59e90c08f535ac44e53d76eeace34e87',
      'native_key' => 'ms2wishlist_frontend_css',
      'filename' => 'modSystemSetting/4425ce6697e66fdfa7a4a28e9ea52cf0.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e4521c7643767836b57e114a046b529',
      'native_key' => 'ms2wishlist_frontend_js',
      'filename' => 'modSystemSetting/177c5b7a8eff274b848008d22caab34a.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '9ed652fcb0586283c9de0ed41e623a2d',
      'native_key' => 0,
      'filename' => 'modChunk/edaf57c16c5a0541deb961390b523908.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'de256758d0bde8a9eedadfde5afc5709',
      'native_key' => 0,
      'filename' => 'modChunk/7289bc0a506dc490ba12919878e012eb.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '824ff8cc3265e015872a6c75a351d928',
      'native_key' => 0,
      'filename' => 'modChunk/ea664c9f2b5edd42ff4463ebc29b975a.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'b20be2aa2de974d0d6549d06d8509afe',
      'native_key' => 0,
      'filename' => 'modChunk/8c5e9700e66c7e3283da6108d893f356.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '7c8a26c448b2ac3f9fb3c7de2a20ae2c',
      'native_key' => 0,
      'filename' => 'modSnippet/29a398fc9ad7f8ee79045a60108b0faa.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'eaf7158bd3e43e94c9498868dbfcfd95',
      'native_key' => 0,
      'filename' => 'modSnippet/8748ba8ef1e2ffa9a35579643e744030.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '7a8185b78122fcf740086cac417621f8',
      'native_key' => 0,
      'filename' => 'modSnippet/ed81b2591c45b7a219bab99b3156f05b.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '6c3191badf30041b56042c8c4e3aaf1d',
      'native_key' => 0,
      'filename' => 'modPlugin/40171790f23aecdbc3faaee4eb331990.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a2ffadde6be74cd2b0db359732ae23dd',
      'native_key' => 1,
      'filename' => 'modCategory/9643a0f0da4547e4d32924ff8c00d42c.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '1b57221dd3dcc92e738395e2774de240',
      'native_key' => '1b57221dd3dcc92e738395e2774de240',
      'filename' => 'xPDOScriptVehicle/b1503c4707d616ed6deba9263537a2d3.vehicle',
      'namespace' => 'ms2wishlist',
    ),
  ),
);