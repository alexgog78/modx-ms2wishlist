<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Wishlist.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Wishlist
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Wishlist
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'miniShop2' => '>=2.4.0',
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2ff80f709a612162e631393a1a788975',
      'native_key' => 'ms2wishlist',
      'filename' => 'modNamespace/1d115512959b9fe66f90d277473feca3.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '32a61a2f0c7fbae77155a2af7feee81e',
      'native_key' => '32a61a2f0c7fbae77155a2af7feee81e',
      'filename' => 'xPDOFileVehicle/7f33f9d10564c0636259c5b72153069d.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '908b80714186849cc7db9cc1e382a99e',
      'native_key' => '908b80714186849cc7db9cc1e382a99e',
      'filename' => 'xPDOFileVehicle/e48374761990c6114273823a468234e8.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '315d049597d976b212053ffa18e05fb4',
      'native_key' => 'ms2wishlist_check_context',
      'filename' => 'modSystemSetting/eca77befd7cf65b3f211007049a25a01.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba226ce3caa468858d8843127ee73346',
      'native_key' => 'ms2wishlist_frontend_css',
      'filename' => 'modSystemSetting/a1c80c7c4667dde046b6a2bd8850c327.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de1b0f4814ce9f2ce93862ecf3810764',
      'native_key' => 'ms2wishlist_frontend_js',
      'filename' => 'modSystemSetting/7c79da1e06484f48a4f09abc36ee729b.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'b80b62d16dad18663d3c1fad61d180cb',
      'native_key' => 0,
      'filename' => 'modChunk/080be77baf5c2a61594d43ce8273d4e4.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '83a23ea95cd0aeeb27bd6428d702a041',
      'native_key' => 0,
      'filename' => 'modChunk/cc8524c94859c085316baf4b41423594.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '4f8c8df2a4de0144cd78622472ecf193',
      'native_key' => 0,
      'filename' => 'modChunk/fd79b65c342a4e6148824f941b5a7c8a.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '851d0b32308d79c029dda4cdc3bb234b',
      'native_key' => 0,
      'filename' => 'modChunk/d7c954aee884260b39311ce0e21499cf.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '35ae488aed63aa712e2f018650f23829',
      'native_key' => 0,
      'filename' => 'modSnippet/aa1a7cd0f4361b347c2ff04bbca6f7c5.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '62ae975efe4071180390d635e1d83917',
      'native_key' => 0,
      'filename' => 'modSnippet/02d9a226e50eff252aee6156026501d2.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '9b202406648481d2cc08426183ccc302',
      'native_key' => 0,
      'filename' => 'modSnippet/2db75cbec3f6d8916b072f40340ae653.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '82a9e8c50cfa0526e8da78f3dfd34fd2',
      'native_key' => 0,
      'filename' => 'modPlugin/46a64c28eca8ddd397b3869e22e9e778.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4c94e7813c9a7ed84eaeeba35c17d764',
      'native_key' => 1,
      'filename' => 'modCategory/8a5eb77fbc517136005df693061ca4ef.vehicle',
      'namespace' => 'ms2wishlist',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '6561a892ea55980ddb4348fbb5a32bc2',
      'native_key' => '6561a892ea55980ddb4348fbb5a32bc2',
      'filename' => 'xPDOScriptVehicle/baaf33bef00d4c4adf96a2f4c3855fcc.vehicle',
      'namespace' => 'ms2wishlist',
    ),
  ),
);