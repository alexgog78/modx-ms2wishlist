<?php

$prefix = 'ms2wishlist_';

$_lang[$prefix . 'scs_add'] = 'Товар добавлен в избранное';
$_lang[$prefix . 'scs_remove'] = 'Товар удален из избранного';
$_lang[$prefix . 'scs_clear'] = 'Список избранного очищен';

$_lang[$prefix . 'err_response_format'] = 'Неверный формат ответа';
$_lang[$prefix . 'err_action_nf'] = 'Дейсвие не найдено: "[[+action]]"';
