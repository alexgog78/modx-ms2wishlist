<?php

$prefix = 'ms2wishlist_';
$_lang['ms2wishlist'] = 'Избранные товары';

$_lang[$prefix . 'desc'] = 'Избранные товары miniShop2';
$_lang[$prefix . 'add'] = 'Добавить в избранное';
$_lang[$prefix . 'remove'] = 'Удалить из избранного';
$_lang[$prefix . 'clear'] = 'Очистить список избранного';
$_lang[$prefix . 'count'] = 'Товаров';
$_lang[$prefix . 'is_empty'] = 'Список избранного пуст';
